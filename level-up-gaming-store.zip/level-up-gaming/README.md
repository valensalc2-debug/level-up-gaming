# LEVEL UP — Gaming Store

## Publicar en GitHub Pages
1. Crea un repositorio nuevo llamado `level-up-gaming`.
2. Añade el archivo `index.html` de esta carpeta a la raíz del repositorio.
3. En GitHub abre Settings → Pages.
4. En Build and deployment elige `Deploy from a branch`, la rama `main` (o `principal`) y la carpeta `/(root)`; guarda.
5. Espera a que GitHub Pages muestre la URL y ábrela.

## WhatsApp
En `index.html`, al principio del script, cambia:
`whatsappNumber: ""`
por el número de la tienda en formato internacional, solo dígitos, sin `+`, espacios ni guiones. Ejemplo de formato argentino ficticio: `5493431234567`. Si no hay un número definido, el sitio no envía ni inventa pedidos.

## Limitaciones importantes
- GitHub Pages aloja sitios estáticos; no ejecuta un servidor ni procesa pagos.
- El panel Admin de esta demo guarda cambios en `localStorage` del navegador actual. No es privado, no sincroniza con otros dispositivos y no es seguro para una tienda real.
- El carrito también se guarda localmente en el navegador.
- Los productos y precios son ejemplos: actualízalos antes de compartir la tienda.
- Para cuentas de usuario, administración segura, pedidos persistentes y pagos reales se necesita backend/base de datos y un proveedor de pagos adecuado. Nunca guardes contraseñas o claves secretas dentro de este HTML.
